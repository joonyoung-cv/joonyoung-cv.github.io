This package is a MATLAB implementation of our paper

- "Radiometric Calibration by Rank Minimization"
Joon-Young Lee, Yasuyuki Matsushita, Boxin Shi, In So Kweon, and Katsushi Ikeuchi
IEEE Transactions on Pattern Analysis and Machine Intelligence (TPAMI), Volume 35, 
Number 1, Pages 144-156, Jan 2013

- "Radiometric Calibration by Transform Invariant Low-rank Structure"
Joon-Young Lee, Boxin Shi, Yasuyuki Matsushita, In So Kweon, and Katsushi Ikeuchi
In Proc. of IEEE Conference on Computer Vision and Pattern Recognition (CVPR), Jun 2011

Please cite our paper if you use any part of the code.
If you find any bug, please contact xenon00@gmail.com.

% ----------------------------------------------------------------------
% Permission to use, copy, or modify this software and its documentation
% for educational and research purposes only and without fee is here
% granted, provided that this copyright notice and the original authors'
% names appear on all copies and supporting documentation. This program
% shall not be used, rewritten, or adapted as the basis of a commercial
% software or hardware product without first obtaining permission of the
% authors. The authors make no representations about the suitability of
% this software for any purpose. It is provided "as is" without express
% or implied warranty.
%----------------------------------------------------------------------
