function cost = funGammaForExposureEstimation(coeff, ref_point_for_exposure_estimation, gamma)

ref_y = polyval(coeff, ref_point_for_exposure_estimation(1)) .^ gamma;

cost = ref_point_for_exposure_estimation(2) - ref_y;