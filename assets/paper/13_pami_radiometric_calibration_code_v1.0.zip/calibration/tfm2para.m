function tau=tfm2para(tfm_matrix)
% tfm2para will transpose tfm_matrix to its corresponding parameter.
% -------------------------input------------------------------------------
% tfm_matrix:       Nth order polynomial coefficient matrix.
% -------------------------output-----------------------------------------
% tau:              p-by-1 real vector.
nTfm_matrix = length(tfm_matrix);
tau = zeros(1, nTfm_matrix-2);
tau(1)=tfm_matrix(1);
for i=2:nTfm_matrix-2
    tau(i) = tfm_matrix(i) + tau(i-1);
end
