function error = funMitsunaga(obs_mat, expRatio, tau)

coeff = para2tfm(tau);
Dotau = polyval(coeff, obs_mat);
nRatios = numel(expRatio);
cost = zeros(size(Dotau,1), nRatios);

for i=1:nRatios
     cost(:,i) = Dotau(:,i) - expRatio(i) * Dotau(:,i+1);
end

% monotonicity constraint
step = 1/100;
step_min = 0;
x = 0:step:1;
y = polyval(coeff, x);
dy = y(2:end) - y(1:end-1);
mono_cost = sum(dy<=step_min);

error = [cost(:); 1e10*mono_cost];

