function cost = funRankPoly(obs_mat, tau)

coeff = para2tfm(tau);
Dotau = polyval(coeff, obs_mat);
s = svd(Dotau, 'econ');
s = s / s(1);
rank_cost = s(2);

% monotonicity constraint
step = 1/100;
step_min = 1e-4;
x = 0:step:1;
y = polyval(coeff, x);
dy = y(2:end) - y(1:end-1);
mono_cost = sum(dy<=step_min);

cost = [sqrt(rank_cost); 1e10*mono_cost ];


