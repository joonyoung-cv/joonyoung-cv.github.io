function [res] = Mitsunaga(args)

if ~isfield(args, 'n_poly')
    args.n_poly = 5;
end

if ~isfield(args, 'option_mits_lm')
    args.option_mits_lm = optimset('Algorithm', 'levenberg-marquardt', ...
        'MaxFunEvals',1e6,'MaxIter',1e6,'PlotFcns', [], 'Display','off');
end

if isfield(args, 'use_given_initial') && isfield(args, 'initial') && args.use_given_initial
    coeff = args.initial;
else
    coeff = zeros(1, args.n_poly+1);
    coeff(end-1) = 1;
end
tau = tfm2para(coeff);

if ~isfield(args, 'exposure') || length(args.exposure) ~= size(args.obs_mat,2)
    args.exposure = mean(args.obs_mat);
end
    

expRatio = args.exposure(1:end-1) ./ args.exposure(2:end);

tStart = tic;
[tau, fval] = lsqnonlin(@(tau) funMitsunaga(args.obs_mat, expRatio, tau), tau, [], [], args.option_mits_lm);
res.time = toc(tStart);
res.coeff = para2tfm(tau);
res.fval = fval;
res.gamma = 1;
