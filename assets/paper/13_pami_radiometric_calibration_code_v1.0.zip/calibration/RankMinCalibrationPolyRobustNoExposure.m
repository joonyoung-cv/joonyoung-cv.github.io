function res = RankMinCalibrationPolyRobustNoExposure(args)

if ~isfield(args, 'n_poly')
    args.n_poly = 10;
end

if ~isfield(args, 'option_rank_lm')
    args.option_rank_lm = optimset('Algorithm', 'levenberg-marquardt', ...
        'MaxFunEvals',1e6,'MaxIter',1e6,'PlotFcns', [], 'Display','off');
end

if ~isfield(args, 'option_rank_gamma')
    args.option_rank_gamma = optimset('Algorithm', 'levenberg-marquardt', ...
        'MaxFunEvals',1e3,'MaxIter',1e3,'PlotFcns', [], 'Display','off');
end

if ~isfield(args, 'tau1')
    args.tau1 = 3;
end

if ~isfield(args, 'tau2')
    args.tau2 = 3;
end

if isfield(args, 'use_given_initial') && isfield(args, 'initial') && args.use_given_initial
    coeff = args.initial;
else
    coeff = zeros(1, args.n_poly+1);
    coeff(end-1) = 1;
end
tau = tfm2para(coeff);

if ~isfield(args, 'ref_point_for_exposure_estimation')
    args.ref_point_for_exposure_estimation = [0.8 0.4];
end

tStart = tic;
[tau, fval] = lsqnonlin(@(tau) funRankPolyRobust(args.obs_mat, tau, args.tau2), tau, [], [], args.option_rank_lm);
res.time = toc(tStart);
res.fval = fval;

coeff = para2tfm(tau);
Dotau = polyval(coeff, args.obs_mat);

A = Dotau;
for iter=1:100
    [U S V] = svd(A, 'econ');
    low_rank = U(:,1) * S(1) * V(:,1)';
    high_rank = A-low_rank;
    avg = mean(high_rank(:));
    st = std(high_rank(:));
    dE = (abs(high_rank-avg) > 0.005+args.tau1*st) .* high_rank;
    A = A - dE;
    if norm(dE) < 1e-7
        break;
    end
end

A = min(1,max(0,A));

tStart = tic;
[gamma, fval] = lsqnonlin(@(gamma) funGammaForExposureEstimation(coeff, args.ref_point_for_exposure_estimation, gamma), 1, [], [], args.option_rank_gamma);
res.time = res.time + toc(tStart);

A = A.^gamma;
A2 = mean(A);

res.exposure = A2(:)' / A2(end);
res.coeff = coeff;
res.gamma = gamma;
res.fval_g = fval;
