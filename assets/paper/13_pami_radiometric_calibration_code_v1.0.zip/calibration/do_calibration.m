function est_y_final = do_calibration( obs, exposure )

n_trials = 5;
samplingNumber = 1000;

g_x = linspace(0,1,256);
est_y = zeros(n_trials,256);

for i = 1:n_trials
    disp(['trial - ' num2str(i)]);

    args = [];
    args.obs_mat = obs(unique(randi(size(obs,1), [1 samplingNumber])), :);
    args.exposure = exposure;
    args.n_poly = 6;
    res = RankMinCalibrationPolyRobust(args);

    est_y(i,:)  = max(0, min(1, polyval(res.coeff, g_x))) .^ res.gamma;
end

est_y_final = median(est_y,1);
