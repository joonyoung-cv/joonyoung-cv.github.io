function [res] = RankMinCalibrationPoly(args)

if ~isfield(args, 'n_poly')
    args.n_poly = 9;
end

if ~isfield(args, 'option_rank_lm')
    args.option_rank_lm = optimset('Algorithm', 'levenberg-marquardt', ...
        'MaxFunEvals',1e6,'MaxIter',1e6,'PlotFcns', [], 'Display','off');
end

if ~isfield(args, 'option_rank_gamma')
    args.option_rank_gamma = optimset('Algorithm', 'levenberg-marquardt', ...
        'MaxFunEvals',1e3,'MaxIter',1e3,'PlotFcns', [], 'Display','off');
end

if isfield(args, 'use_given_initial') && isfield(args, 'initial') && args.use_given_initial
    coeff = args.initial;
else
    coeff = zeros(1, args.n_poly+1);
    coeff(end-1) = 1;
end
tau = tfm2para(coeff);

if ~isfield(args, 'exposure') || length(args.exposure) ~= size(args.obs_mat,2)
    args.exposure = mean(args.obs_mat);
end

tStart = tic;
[tau, fval] = lsqnonlin(@(tau) funRankPoly(args.obs_mat, tau), tau, [], [], args.option_rank_lm);
res.time = toc(tStart);
res.fval = fval;

coeff = para2tfm(tau);
Dotau = polyval(coeff, args.obs_mat);
tStart = tic;
[gamma, fval] = lsqnonlin(@(gamma) funGamma(Dotau, args.exposure, gamma), 1, [], [], args.option_rank_gamma);
res.time = res.time + toc(tStart);

res.coeff = coeff;
res.gamma = gamma;
res.fval_g = fval;
