function tfm_matrix=para2tfm(tau)
% para2tfm will turn tau to tfm_matrix
% ----------------------------input---------------------------------------
% tau:      p-by-1 vector
% ----------------------------output--------------------------------------
% tfm_matrix:   Nth order polynomial coefficient matrix.
nTau = length(tau);
tfm_matrix = zeros(1,nTau+2);
tfm_matrix(1) = tau(1);
for i=2:nTau
    tfm_matrix(i) = tau(i) - tau(i-1);
end
tfm_matrix(nTau+1) = 1-tau(end);
tfm_matrix(nTau+2) = 0;
