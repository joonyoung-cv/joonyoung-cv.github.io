function cost = funExposureEstimation(A, exposure)

expRatio = exposure(1:end-1) / exposure(end);
nRatios = numel(expRatio);
cost = zeros(size(A,1), nRatios);

for i=1:nRatios
    cost(:,i) = A(:,i) - expRatio(i) * A(:,i+1);
end
