close all
clear all
addpath('calibration');

datadir = 'ArchSequence';
filelist = {'A_1.jpg', 'A_2_03.jpg', 'A_3_02.jpg', 'A_4_06.jpg'};
exposure = [1/500 1/250 1/125 1/60];

% datadir = 'eos550d_resized';
% filelist = {'1.JPG','2.JPG','3.JPG','4.JPG','5.JPG','6.JPG','7.JPG','8.JPG','9.JPG'};
% exposure = [ 0.0004, 0.000625, 0.001, 0.001563, 0.0025, 0.004, 0.00625, 0.01, 0.016667 ];

%%
CRF = cell(3,1);
for nChannel = 1:3
    [candidate_all,candidate_set] = extract_data_from_real_images(datadir, filelist, nChannel, []);
    myexposure = exposure(candidate_set);
    
    CRF{nChannel} = do_calibration( candidate_all, myexposure );
    
    %% plot figure
    g_x = linspace(0,1,256);
    h=figure;
    set(h, 'Position', [100 500 450 400]);
    plot(g_x, CRF{nChannel});
    axis([0 1 0 1]);
    grid on;
    set(gca, 'XTick', 0:0.1:1);
    set(gca, 'YTick', 0:0.1:1);
    xlabel('Normalized observation');
    ylabel('Normalized irradiance');
end

%% show an example result
img_filename = fullfile(datadir,filelist{ceil(numel(filelist)/2)});
i1 = im2double(imread(img_filename));
i1_lin = applyCRF( i1, CRF );
figure; imshow( [i1, i1_lin] );
